Files like headerfiles , makefiles and code libraries that submission needs can be stored here.
If you are using this for other programming languages like Standard ML, you can save mlton binaries here to build sml files using ./mlton
