#!/usr/bin/env bash

python3 --version
apt-get install valgrind -y